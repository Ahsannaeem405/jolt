<?php

namespace App\Interfaces;

interface mail_messasge {

    const order='Thank You for your Subscription';
    const deactive='Subscription Deactivated successfully';
    const activated='Subscription Activated successfully';
    const error='Payment not successful';
    const payment='Thank You for your payment';
    const otp='OTP Verification from JOLT';

}

